describe('Sentinl', function () {
  require('../lib/validators/__tests__/validators');
  require('../lib/classes/__tests__/watcher');
});
