import { uiModules } from 'ui/modules';
import 'angular-ui-bootstrap';

const app = uiModules.get('apps/sentinl', ['ui.bootstrap']);
export { app };
